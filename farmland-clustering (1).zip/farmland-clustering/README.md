# Farmland Zone Clustering (frontend)

## Run it
```
npm install
npm run dev
```
Open the URL Vite prints (usually http://localhost:5173). Requires Node 18+.

## What is real and what is mock
- **Synthetic:** the 120 sample records (`src/data/mockFarmlandData.js`). Not real survey data.
- **Real calculations (in the browser):** EDA statistics, correlations, K-Means, silhouette, WCSS, Ward hierarchical clustering, cluster summaries (`src/utils/statistics.js`).
- **Reference only:** the notebook values in `src/data/mockMetrics.js` (silhouette K=2 ~0.337, K=3 ~0.301, correlation ~0.74). They are displayed as references, never as results.
- Uploaded CSVs are validated and loaded but get no cluster labels until you run an algorithm.

## Connecting a Python backend later
Replace these functions in `src/utils/statistics.js` with `fetch` calls (e.g. FastAPI + scikit-learn):
| Function | Suggested endpoint |
|---|---|
| `kmeans(X,k)` / `runKMeans` | `POST /api/kmeans {records,k}` -> `{labels, inertia}` |
| `silhouette(X,labels)` | include in the K-Means response, or `POST /api/silhouette` |
| `ward(X)` + `cutTree` | `POST /api/hierarchical {records,k}` -> `{labels, linkage}` (render the dendrogram from scipy's linkage matrix) |
| CSV upload | `POST /api/upload` returning cleaned records |
Keep the `labels` array (one integer per record) as the contract; every page already reads it from `src/context.jsx`.
