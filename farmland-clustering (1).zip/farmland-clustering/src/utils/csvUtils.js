import { FEATURES } from '../data/mockFarmlandData.js';

const norm = (s) => s.toLowerCase().replace(/\(.*?\)/g, '').replace(/[^a-z0-9]/g, '');
const ALIASES = {
  soil: ['soilqualityscore', 'soilquality', 'soil'],
  irrigation: ['irrigationavailability', 'irrigation'],
  rainfall: ['annualrainfall', 'rainfall'],
  yield: ['cropyield', 'yield'],
  area: ['landarea', 'area'],
};

function splitLine(line) {
  const out = []; let cur = '', q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') { if (q && line[i + 1] === '"') { cur += '"'; i++; } else q = !q; }
    else if (ch === ',' && !q) { out.push(cur.trim()); cur = ''; }
    else cur += ch;
  }
  out.push(cur.trim()); return out;
}

export function validateFile(file) {
  const errors = [];
  if (!/\.csv$/i.test(file.name)) errors.push('Choose a .csv file. Other file types are not supported.');
  if (file.size > 2 * 1024 * 1024) errors.push('The file is larger than 2 MB. Upload a smaller CSV.');
  if (file.size === 0) errors.push('The file is empty.');
  return errors;
}

export function parseFarmCSV(text) {
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) return { errors: ['The file needs a header row and at least one data row.'] };
  const rawHeaders = splitLine(lines[0]); const headers = rawHeaders.map(norm);
  const idx = {}, missing = [];
  FEATURES.forEach((f) => { const i = headers.findIndex((h) => ALIASES[f.key].includes(h)); if (i < 0) missing.push(f.label); else idx[f.key] = i; });
  if (missing.length) return { errors: [`Missing required column${missing.length > 1 ? 's' : ''}: ${missing.join(', ')}.`, `Columns found: ${rawHeaders.join(', ')}.`] };
  const idCol = headers.findIndex((h) => ['recordid', 'id', 'farmid'].includes(h));
  const errors = [], records = []; let skipped = 0;
  lines.slice(1).forEach((line, li) => {
    const cells = splitLine(line);
    const row = { id: idCol >= 0 && cells[idCol] ? cells[idCol] : `U-${String(records.length + 1).padStart(3, '0')}` };
    let blank = false, bad = false;
    FEATURES.forEach((f) => {
      const raw = cells[idx[f.key]] ?? '';
      if (raw === '') { blank = true; return; }
      const v = Number(raw);
      if (!Number.isFinite(v)) { bad = true; errors.push(`Row ${li + 2}: "${raw}" in ${f.label} is not a number.`); } else row[f.key] = v;
    });
    if (bad) return;
    if (blank) { skipped++; return; }
    records.push(row);
  });
  if (errors.length > 5) { const n = errors.length - 5; errors.length = 5; errors.push(`…and ${n} more problems.`); }
  if (!errors.length && records.length < 4) errors.push('At least 4 complete rows are needed for clustering.');
  return { records, errors, skipped };
}

export function toCSV(rows) {
  const q = (v) => (/[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : v);
  const head = ['Record ID', ...FEATURES.map((f) => f.label), 'Cluster'];
  return [head, ...rows.map((r) => [r.id, ...FEATURES.map((f) => r[f.key]), r.clusterLabel])].map((l) => l.map(q).join(',')).join('\n');
}
export function download(name, text) {
  const url = URL.createObjectURL(new Blob([text], { type: 'text/csv' }));
  Object.assign(document.createElement('a'), { href: url, download: name }).click();
  URL.revokeObjectURL(url);
}
