// Real calculations, run in the browser. To use a Python backend later,
// replace kmeans / ward / silhouette with fetch() calls (see README).
import { FEATURES, KEYS } from '../data/mockFarmlandData.js';
import { rng } from './rng.js';

const sum = (a) => a.reduce((s, v) => s + v, 0);
export const mean = (a) => sum(a) / a.length;
export const std = (a) => { const m = mean(a); return Math.sqrt(sum(a.map((v) => (v - m) ** 2)) / Math.max(1, a.length - 1)) || 1; };
export const col = (rows, k) => rows.map((r) => r[k]);
export const fmt = (v, d = 1) => (Number.isFinite(v) ? Number(v.toFixed(d)).toLocaleString() : '–');
const quantile = (s, q) => { const p = (s.length - 1) * q, i = Math.floor(p); return s[i] + (s[Math.min(i + 1, s.length - 1)] - s[i]) * (p - i); };

export function describe(a) {
  const s = [...a].sort((x, y) => x - y);
  const q1 = quantile(s, 0.25), q3 = quantile(s, 0.75), iqr = q3 - q1, lo = q1 - 1.5 * iqr, hi = q3 + 1.5 * iqr;
  const inside = s.filter((v) => v >= lo && v <= hi);
  return { n: s.length, mean: mean(s), std: std(s), min: s[0], q1, median: quantile(s, 0.5), q3, max: s[s.length - 1],
    whiskerLo: inside[0], whiskerHi: inside[inside.length - 1], outliers: s.filter((v) => v < lo || v > hi) };
}
export function correlation(a, b) {
  const ma = mean(a), mb = mean(b); let n = 0, da = 0, db = 0;
  a.forEach((v, i) => { n += (v - ma) * (b[i] - mb); da += (v - ma) ** 2; db += (b[i] - mb) ** 2; });
  return da && db ? n / Math.sqrt(da * db) : 0;
}
export function histogram(a, bins = 10) {
  const mn = Math.min(...a), mx = Math.max(...a), w = (mx - mn) / bins || 1;
  const out = Array.from({ length: bins }, (_, i) => ({ range: `${fmt(mn + i * w)}–${fmt(mn + (i + 1) * w)}`, count: 0 }));
  a.forEach((v) => { out[Math.min(bins - 1, Math.floor((v - mn) / w))].count++; });
  return out;
}
export const zscore = (rows, keys = KEYS) => {
  const p = keys.map((k) => { const c = col(rows, k); return [mean(c), std(c)]; });
  return rows.map((r) => keys.map((k, i) => (r[k] - p[i][0]) / p[i][1]));
};

const d2 = (a, b) => a.reduce((s, v, i) => s + (v - b[i]) ** 2, 0);

// Order clusters by size (largest first): labels stay stable and carry no "quality" meaning.
export function relabel(labels) {
  const c = {}; labels.forEach((l) => { c[l] = (c[l] || 0) + 1; });
  const order = Object.keys(c).sort((a, b) => c[b] - c[a]);
  const map = {}; order.forEach((l, i) => { map[l] = i; });
  return labels.map((l) => map[l]);
}

export function kmeans(X, k, seed = 42, restarts = 6) {
  const r = rng(seed); let best = null;
  for (let t = 0; t < restarts; t++) {
    const init = [X[Math.floor(r() * X.length)]];
    while (init.length < k) { // k-means++ seeding
      const d = X.map((x) => Math.min(...init.map((m) => d2(x, m))));
      let s = r() * sum(d), i = 0;
      for (; i < d.length - 1 && (s -= d[i]) > 0; i++);
      init.push(X[i]);
    }
    let cent = init.map((x) => [...x]); const labels = new Array(X.length).fill(-1);
    for (let it = 0; it < 100; it++) {
      let changed = false;
      X.forEach((x, i) => { let b = 0, bd = Infinity; cent.forEach((m, j) => { const d = d2(x, m); if (d < bd) { bd = d; b = j; } }); if (labels[i] !== b) { labels[i] = b; changed = true; } });
      cent = cent.map((m, j) => { const mem = X.filter((_, i) => labels[i] === j); return mem.length ? m.map((_, f) => mean(mem.map((p) => p[f]))) : m; });
      if (!changed) break;
    }
    const wcss = sum(X.map((x, i) => d2(x, cent[labels[i]])));
    if (!best || wcss < best.wcss) best = { labels, wcss };
  }
  return { labels: relabel(best.labels), wcss: best.wcss };
}
export const runKMeans = (rows, k, seed = 42) => kmeans(zscore(rows), k, seed).labels;

export function silhouette(X, labels) {
  const ks = [...new Set(labels)]; if (ks.length < 2) return 0; let tot = 0;
  X.forEach((x, i) => {
    const m = {}; ks.forEach((k) => { m[k] = [0, 0]; });
    X.forEach((y, j) => { if (i !== j) { const e = m[labels[j]]; e[0] += Math.sqrt(d2(x, y)); e[1]++; } });
    const own = m[labels[i]]; if (!own[1]) return;
    const a = own[0] / own[1]; let b = Infinity;
    ks.forEach((k) => { if (k !== labels[i] && m[k][1]) b = Math.min(b, m[k][0] / m[k][1]); });
    tot += (b - a) / Math.max(a, b);
  });
  return tot / X.length;
}

// Agglomerative clustering, Ward linkage (Lance-Williams update). Leaves are nodes[0..n-1]; root is last.
export function ward(X) {
  const n = X.length; const D = X.map((x) => X.map((y) => d2(x, y)));
  const size = Array(n).fill(1), id = [...Array(n).keys()], active = new Set(id);
  const nodes = X.map((_, i) => ({ id: i, height: 0, idx: [i] }));
  while (active.size > 1) {
    const A = [...active]; let bi = -1, bj = -1, bd = Infinity;
    for (let a = 0; a < A.length; a++) for (let b = a + 1; b < A.length; b++) { const d = D[A[a]][A[b]]; if (d < bd) { bd = d; bi = A[a]; bj = A[b]; } }
    const ni = size[bi], nj = size[bj];
    for (const k of active) { if (k === bi || k === bj) continue; const nk = size[k]; D[bi][k] = D[k][bi] = ((ni + nk) * D[bi][k] + (nj + nk) * D[bj][k] - nk * bd) / (ni + nj + nk); }
    nodes.push({ id: nodes.length, left: id[bi], right: id[bj], height: Math.sqrt(bd), idx: [...nodes[id[bi]].idx, ...nodes[id[bj]].idx] });
    size[bi] = ni + nj; id[bi] = nodes.length - 1; active.delete(bj);
  }
  return nodes;
}
export function cutTree(nodes, k) {
  let cur = [nodes[nodes.length - 1]]; let lastSplit = cur[0].height;
  while (cur.length < k) {
    cur.sort((a, b) => b.height - a.height); const t = cur.shift();
    if (t.left === undefined) { cur.push(t); break; }
    lastSplit = t.height; cur.push(nodes[t.left], nodes[t.right]);
  }
  const labels = []; cur.forEach((c, ci) => c.idx.forEach((i) => { labels[i] = ci; }));
  const next = Math.max(...cur.map((c) => c.height));
  return { labels: relabel(labels), threshold: (lastSplit + next) / 2 };
}

export function clusterStats(rows, labels) {
  const k = Math.max(...labels) + 1; const overall = {};
  KEYS.forEach((key) => { const c = col(rows, key); overall[key] = { mean: mean(c), std: std(c) }; });
  const clusters = Array.from({ length: k }, (_, c) => {
    const mem = rows.filter((_, i) => labels[i] === c); const means = {};
    KEYS.forEach((key) => { means[key] = mem.length ? mean(col(mem, key)) : NaN; });
    return { id: c, name: `Cluster ${c + 1}`, count: mem.length, means };
  });
  return { clusters, overall };
}
export function describeCluster(c, overall) {
  const hi = [], lo = [];
  FEATURES.forEach((f) => { const z = (c.means[f.key] - overall[f.key].mean) / overall[f.key].std; if (z >= 0.5) hi.push(f.label.toLowerCase()); else if (z <= -0.5) lo.push(f.label.toLowerCase()); });
  const join = (a) => (a.length > 1 ? `${a.slice(0, -1).join(', ')} and ${a[a.length - 1]}` : a[0]);
  const parts = [];
  if (hi.length) parts.push(`higher ${join(hi)}`);
  if (lo.length) parts.push(`lower ${join(lo)}`);
  return `${c.name} (${c.count} records) has ${parts.length ? parts.join(', but ') : 'values close to the dataset average on every feature'}, compared with the whole dataset.`;
}
