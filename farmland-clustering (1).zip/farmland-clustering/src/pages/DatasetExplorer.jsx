import { useMemo, useRef, useState } from 'react';
import { Upload, Download, Search, RotateCcw } from 'lucide-react';
import { Link } from 'react-router-dom';
import DataTable, { ClusterDot } from '../components/DataTable.jsx';
import { PageHead, Notice } from '../components/ChartCard.jsx';
import { useData } from '../context.jsx';
import { FEATURES } from '../data/mockFarmlandData.js';
import { parseFarmCSV, validateFile, toCSV, download } from '../utils/csvUtils.js';

export default function DatasetExplorer() {
  const { records, labels, source, loadRecords, resetSample, clusterCount } = useData();
  const [q, setQ] = useState(''); const [cf, setCf] = useState('all');
  const [errors, setErrors] = useState([]); const [ok, setOk] = useState('');
  const fileRef = useRef();

  const rows = useMemo(() => records.map((r, i) => ({ ...r, cluster: labels ? labels[i] : -1, clusterLabel: labels ? `Cluster ${labels[i] + 1}` : 'Not clustered' })), [records, labels]);
  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return rows.filter((r) => (cf === 'all' || String(r.cluster) === cf) && (!s || [r.id, r.clusterLabel, ...FEATURES.map((f) => r[f.key])].join(' ').toLowerCase().includes(s)));
  }, [rows, q, cf]);

  async function onFile(e) {
    const f = e.target.files[0]; e.target.value = ''; setOk(''); if (!f) return;
    const pre = validateFile(f); if (pre.length) return setErrors(pre);
    const res = parseFarmCSV(await f.text()); setErrors(res.errors);
    if (res.errors.length) return;
    loadRecords(res.records, { name: f.name, uploaded: true, skipped: res.skipped });
    setOk(`Loaded ${res.records.length} records from ${f.name}${res.skipped ? ` (${res.skipped} rows with blank values were skipped)` : ''}. Run K-Means or hierarchical clustering to label them.`);
    setQ(''); setCf('all');
  }

  const columns = [
    { key: 'id', label: 'Record ID' },
    ...FEATURES.map((f) => ({ key: f.key, label: f.unit ? `${f.label} (${f.unit})` : f.label })),
    { key: 'clusterLabel', label: 'Cluster', render: (r) => (r.cluster >= 0 ? <ClusterDot c={r.cluster} /> : <span className="text-ink/50">Not clustered</span>) },
  ];

  return (
    <div className="space-y-5">
      <PageHead title="Dataset Explorer">Search, sort and filter farmland records. Upload a CSV with these columns: {FEATURES.map((f) => f.label).join(', ')}. A Record ID column is optional.</PageHead>
      <div className="card p-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]"><Search size={16} className="absolute left-3 top-3 text-ink/50" />
          <input className="input w-full pl-9" placeholder="Search records" aria-label="Search records" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <select className="input" aria-label="Filter by cluster" value={cf} onChange={(e) => setCf(e.target.value)} disabled={!labels}>
          <option value="all">All clusters</option>{Array.from({ length: clusterCount || 0 }, (_, c) => <option key={c} value={c}>Cluster {c + 1}</option>)}
        </select>
        <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={onFile} />
        <button className="btn-ghost" onClick={() => fileRef.current.click()}><Upload size={16} /> Upload CSV</button>
        <button className="btn-ghost" onClick={() => download('farmland_records.csv', toCSV(filtered))} disabled={!filtered.length}><Download size={16} /> Export CSV</button>
        {source.uploaded && <button className="btn-ghost" onClick={resetSample}><RotateCcw size={16} /> Use sample</button>}
      </div>
      {errors.length > 0 && <Notice tone="error"><p className="font-medium">This file can't be used:</p><ul className="list-disc ml-5">{errors.map((e) => <li key={e}>{e}</li>)}</ul></Notice>}
      {ok && <Notice tone="ok">{ok}</Notice>}
      {!labels && <Notice>These records have no cluster labels yet. Go to <Link className="underline" to="/dashboard/kmeans">K-Means</Link> or <Link className="underline" to="/dashboard/hierarchical">Hierarchical Clustering</Link> to create them. Any cluster column in your file is ignored.</Notice>}
      <div className="card p-5">
        <p className="text-sm text-ink/70 mb-3">Showing {filtered.length} of {records.length} records · {source.name}</p>
        <DataTable columns={columns} rows={filtered} empty="No records match your search or filter. Clear the search box or choose All clusters." />
      </div>
    </div>
  );
}
