import { useMemo, useState } from 'react';
import { LineChart, Line, ScatterChart, Scatter, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid, ReferenceDot } from 'recharts';
import { Play } from 'lucide-react';
import ChartCard, { PageHead, Notice } from '../components/ChartCard.jsx';
import { ClusterTable } from '../components/DataTable.jsx';
import { useData } from '../context.jsx';
import { FEATURES } from '../data/mockFarmlandData.js';
import { CLUSTER_COLORS, REFERENCE } from '../data/mockMetrics.js';
import { zscore, kmeans, silhouette, relabel, clusterStats, fmt } from '../utils/statistics.js';

const TERMS = [
  ['Centroid', 'The average position of all farms in a cluster. K-Means moves centroids until assignments stop changing.'],
  ['Euclidean distance', 'Straight-line distance between two farms. Features are standardized first so rainfall in mm does not outweigh soil score.'],
  ['WCSS / inertia', 'Sum of squared distances from each farm to its centroid. Lower means tighter clusters, but it always falls as K grows.'],
  ['Silhouette score', 'How well each farm fits its own cluster versus the nearest other one, from -1 to 1. Higher is better.'],
];

export default function KMeans() {
  const { records, labels, setLabels, setAlgo, clusterCount } = useData();
  const X = useMemo(() => zscore(records), [records]);
  const [sel, setSel] = useState(clusterCount || 3);
  const [runs, setRuns] = useState(0);
  const [xk, setXk] = useState('soil'); const [yk, setYk] = useState('yield');
  const curve = useMemo(() => [1, 2, 3, 4, 5, 6, 7, 8].map((k) => { const r = kmeans(X, k, 7); return { k, wcss: +r.wcss.toFixed(1), sil: k > 1 ? +silhouette(X, r.labels).toFixed(3) : null }; }), [X]);
  const bestSil = curve.filter((c) => c.sil != null).reduce((a, b) => (b.sil > a.sil ? b : a));
  const stats = labels ? clusterStats(records, labels) : null;

  const run = () => { const r = kmeans(X, sel, 42 + runs * 17); setLabels(r.labels); setAlgo('K-Means'); setRuns(runs + 1); };
  const xf = FEATURES.find((f) => f.key === xk), yf = FEATURES.find((f) => f.key === yk);
  const pts = (c) => records.filter((_, i) => labels[i] === c).map((r) => ({ x: r[xk], y: r[yk], id: r.id }));
  const cents = stats ? stats.clusters.map((c) => ({ x: c.means[xk], y: c.means[yk], id: c.name })) : [];

  return (
    <div className="space-y-6">
      <PageHead title="K-Means Clustering">K-Means assigns each farm to its nearest centroid, recomputes the centroids, and repeats until nothing changes.</PageHead>
      <Notice>This runs a real K-Means (k-means++ start, standardized features) in your browser on the loaded data. The sample data is synthetic, and the project reference scores (K=2 ≈ {REFERENCE.silhouetteK2}, K=3 ≈ {REFERENCE.silhouetteK3}) are not reproduced here.</Notice>
      <div className="card p-4 flex flex-wrap items-center gap-4">
        <label className="text-sm font-medium">Number of clusters (K)
          <select className="input ml-2" value={sel} onChange={(e) => setSel(+e.target.value)}>{[2, 3, 4, 5, 6, 7, 8].map((k) => <option key={k}>{k}</option>)}</select></label>
        <button className="btn-primary" onClick={run}><Play size={16} /> Run K-Means</button>
        <span className="text-sm text-ink/70">Each run uses a new random start, so small changes in the result can occur.</span>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <ChartCard title="Elbow method" subtitle="WCSS (inertia) for K = 1 to 8. Look for where the drop flattens.">
          <ResponsiveContainer width="100%" height={260}><LineChart data={curve} margin={{ left: 10, right: 10 }}><CartesianGrid stroke="#e3ebdd" />
            <XAxis dataKey="k" label={{ value: 'K', position: 'insideBottom', offset: -2 }} /><YAxis label={{ value: 'WCSS', angle: -90, position: 'insideLeft' }} /><Tooltip />
            <Line type="monotone" dataKey="wcss" name="WCSS" stroke="#1f6b45" strokeWidth={2.5} dot /></LineChart></ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Silhouette score" subtitle={`In this data the highest score is at K = ${bestSil.k} (${bestSil.sil}).`}>
          <ResponsiveContainer width="100%" height={260}><LineChart data={curve.filter((c) => c.sil != null)} margin={{ left: 10, right: 10 }}><CartesianGrid stroke="#e3ebdd" />
            <XAxis dataKey="k" label={{ value: 'K', position: 'insideBottom', offset: -2 }} /><YAxis domain={[0, 1]} label={{ value: 'Silhouette', angle: -90, position: 'insideLeft' }} /><Tooltip />
            <Line type="monotone" dataKey="sil" name="Silhouette" stroke="#d9a441" strokeWidth={2.5} dot />
            <ReferenceDot x={bestSil.k} y={bestSil.sil} r={7} fill="#1f4a32" stroke="none" /></LineChart></ResponsiveContainer>
        </ChartCard>
      </div>

      {!labels ? <Notice>No clusters yet for this dataset. Choose K and select Run K-Means.</Notice> : (
        <>
          <ChartCard title={`Clusters: ${xf.short} vs ${yf.short}`} subtitle={`${clusterCount} clusters from the latest run. Diamonds mark centroids.`}
            actions={<div className="flex gap-2 text-sm">
              {[['X', xk, setXk], ['Y', yk, setYk]].map(([n, v, set]) => <label key={n}>{n}: <select className="input !py-1" value={v} onChange={(e) => set(e.target.value)}>{FEATURES.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}</select></label>)}</div>}>
            <ResponsiveContainer width="100%" height={380}><ScatterChart margin={{ left: 10, bottom: 20, right: 10 }}><CartesianGrid stroke="#e3ebdd" />
              <XAxis type="number" dataKey="x" name={xf.label} domain={['auto', 'auto']} label={{ value: `${xf.label}${xf.unit ? ` (${xf.unit})` : ''}`, position: 'insideBottom', offset: -12 }} />
              <YAxis type="number" dataKey="y" name={yf.label} domain={['auto', 'auto']} label={{ value: `${yf.label}${yf.unit ? ` (${yf.unit})` : ''}`, angle: -90, position: 'insideLeft' }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} /><Legend verticalAlign="top" />
              {Array.from({ length: clusterCount }, (_, c) => <Scatter key={c} name={`Cluster ${c + 1}`} data={pts(c)} fill={CLUSTER_COLORS[c]} fillOpacity={0.8} />)}
              <Scatter name="Centroids" data={cents} fill="#1b2a21" shape="diamond" legendType="diamond" /></ScatterChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Cluster summary" subtitle="Average of each feature per cluster, in original units."><ClusterTable stats={stats} /></ChartCard>
        </>
      )}

      <section className="card p-5"><h3 className="text-lg font-semibold mb-3">Key terms</h3>
        <dl className="grid md:grid-cols-2 gap-4 text-sm">{TERMS.map(([t, d]) => <div key={t}><dt className="font-semibold text-forest">{t}</dt><dd className="text-ink/75">{d}</dd></div>)}</dl></section>
    </div>
  );
}
