import { Link } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid, ReferenceLine } from 'recharts';
import ChartCard, { PageHead, Notice } from '../components/ChartCard.jsx';
import { ClusterDot } from '../components/DataTable.jsx';
import { useData } from '../context.jsx';
import { FEATURES } from '../data/mockFarmlandData.js';
import { CLUSTER_COLORS } from '../data/mockMetrics.js';
import { clusterStats, describeCluster, fmt } from '../utils/statistics.js';

export default function ClusterInsights() {
  const { records, labels, algo } = useData();
  if (!labels) return <div className="space-y-4"><PageHead title="Cluster Insights">Interpret what each cluster looks like.</PageHead>
    <Notice>No clusters exist for this dataset yet. Run <Link className="underline" to="/dashboard/kmeans">K-Means</Link> or <Link className="underline" to="/dashboard/hierarchical">Hierarchical Clustering</Link> first.</Notice></div>;
  const { clusters, overall } = clusterStats(records, labels);
  const chart = FEATURES.map((f) => ({ feature: f.short, ...Object.fromEntries(clusters.map((c) => [c.name, +((c.means[f.key] - overall[f.key].mean) / overall[f.key].std).toFixed(2)])) }));

  return (
    <div className="space-y-6">
      <PageHead title="Cluster Insights">Based on the {algo} result with {clusters.length} clusters. Descriptions are generated from the cluster averages, so they change whenever the clustering changes. Cluster numbers have no built-in meaning.</PageHead>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {clusters.map((c) => (
          <div key={c.id} className="card p-5 border-t-4" style={{ borderTopColor: CLUSTER_COLORS[c.id] }}>
            <h3 className="text-lg font-semibold"><ClusterDot c={c.id} /></h3><p className="text-3xl font-serif font-bold mt-1">{c.count}<span className="text-sm font-sans font-normal text-ink/60"> records</span></p>
            <p className="text-sm text-ink/75 mt-2">{describeCluster(c, overall)}</p></div>))}
      </div>
      <ChartCard title="Cluster comparison" subtitle="Each bar shows how far a cluster's average is from the dataset average, in standard deviations (0 = average). Standardizing makes features with different units comparable.">
        <ResponsiveContainer width="100%" height={340}><BarChart data={chart} margin={{ left: 0, right: 10 }}><CartesianGrid stroke="#e3ebdd" vertical={false} /><XAxis dataKey="feature" />
          <YAxis label={{ value: 'Std. deviations from average', angle: -90, position: 'insideLeft', fontSize: 11 }} /><Tooltip /><Legend /><ReferenceLine y={0} stroke="#1b2a21" />
          {clusters.map((c) => <Bar key={c.id} dataKey={c.name} fill={CLUSTER_COLORS[c.id]} radius={[3, 3, 0, 0]} />)}</BarChart></ResponsiveContainer>
      </ChartCard>
      <ChartCard title="Feature-wise comparison" subtitle="Average values in original units. Bold marks the highest cluster for each feature.">
        <div className="overflow-x-auto rounded-xl border border-sage-200"><table className="w-full text-sm">
          <thead><tr><th className="th">Feature</th>{clusters.map((c) => <th key={c.id} className="th">{c.name}</th>)}<th className="th">All records</th></tr></thead>
          <tbody>{FEATURES.map((f) => { const top = Math.max(...clusters.map((c) => c.means[f.key])); return (
            <tr key={f.key} className="border-t border-sage-100"><td className="td">{f.label}{f.unit && ` (${f.unit})`}</td>
              {clusters.map((c) => <td key={c.id} className={`td ${c.means[f.key] === top ? 'font-bold text-forest' : ''}`}>{fmt(c.means[f.key], 2)}</td>)}<td className="td text-ink/70">{fmt(overall[f.key].mean, 2)}</td></tr>); })}</tbody></table></div>
      </ChartCard>
    </div>
  );
}
