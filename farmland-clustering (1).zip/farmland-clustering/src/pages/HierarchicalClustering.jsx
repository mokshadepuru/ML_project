import { useMemo, useState } from 'react';
import ChartCard, { PageHead, Notice } from '../components/ChartCard.jsx';
import { ClusterTable } from '../components/DataTable.jsx';
import { useData } from '../context.jsx';
import { CLUSTER_COLORS } from '../data/mockMetrics.js';
import { zscore, ward, cutTree, kmeans, silhouette, clusterStats, fmt } from '../utils/statistics.js';

const GREY = '#9aa79a';

function Dendrogram({ nodes, labels, threshold }) {
  const n = (nodes.length + 1) / 2, root = nodes[nodes.length - 1];
  const pos = useMemo(() => {
    const p = {}; let i = 0;
    const walk = (nd) => { if (nd.left === undefined) { p[nd.id] = i++; return; } walk(nodes[nd.left]); walk(nodes[nd.right]); p[nd.id] = (p[nd.left] + p[nd.right]) / 2; };
    walk(root); return p;
  }, [nodes]);
  const step = 9, L = 48, W = L + n * step + 12, H = 360, T = 14, B = 26;
  const x = (id) => L + pos[id] * step + step / 2;
  const y = (h) => T + (H - T - B) * (1 - h / root.height);
  const color = (nd) => { const s = new Set(nd.idx.map((i) => labels[i])); return s.size === 1 ? CLUSTER_COLORS[[...s][0]] : GREY; };
  return (
    <div className="overflow-x-auto"><svg width={W} height={H} role="img" aria-label="Dendrogram">
      {[0, 0.25, 0.5, 0.75, 1].map((t) => <g key={t}><line x1={L - 4} x2={W} y1={y(root.height * t)} y2={y(root.height * t)} stroke="#e3ebdd" /><text x={L - 8} y={y(root.height * t) + 4} fontSize="10" textAnchor="end">{fmt(root.height * t, 1)}</text></g>)}
      {nodes.filter((nd) => nd.left !== undefined).map((nd) => { const l = nodes[nd.left], r = nodes[nd.right];
        return <path key={nd.id} d={`M${x(l.id)} ${y(l.height)} V${y(nd.height)} H${x(r.id)} V${y(r.height)}`} fill="none" stroke={color(nd)} strokeWidth="1.4"><title>Merge height {fmt(nd.height, 2)} · {nd.idx.length} farms</title></path>; })}
      <line x1={L} x2={W} y1={y(threshold)} y2={y(threshold)} stroke="#b5523b" strokeDasharray="6 4" strokeWidth="1.5" />
      <text x={W - 6} y={y(threshold) - 5} fontSize="11" textAnchor="end" fill="#b5523b">cut at {fmt(threshold, 2)}</text>
      <text x={L + (n * step) / 2} y={H - 6} fontSize="11" textAnchor="middle">Farm records (each branch end is one farm)</text>
      <text transform={`translate(11 ${H / 2}) rotate(-90)`} fontSize="11" textAnchor="middle">Merge distance</text>
    </svg></div>
  );
}

export default function HierarchicalClustering() {
  const { records, setLabels, setAlgo, algo, labels: active } = useData();
  const X = useMemo(() => zscore(records), [records]);
  const nodes = useMemo(() => ward(X), [X]);
  const [k, setK] = useState(3); const [used, setUsed] = useState(false);
  const { labels, threshold } = useMemo(() => cutTree(nodes, k), [nodes, k]);
  const km = useMemo(() => kmeans(X, k, 42).labels, [X, k]);
  const stats = clusterStats(records, labels);
  const table = Array.from({ length: k }, (_, h) => Array.from({ length: k }, (_, c) => labels.filter((l, i) => l === h && km[i] === c).length));

  return (
    <div className="space-y-6">
      <PageHead title="Hierarchical Clustering">Agglomerative clustering starts with every farm on its own and repeatedly merges the two closest groups. Here, "closest" means the merge that least increases within-group variance (Ward linkage) on standardized features.</PageHead>
      <Notice>The dendrogram is computed from the loaded data in your browser. The sample data itself is synthetic.</Notice>
      <div className="card p-4 flex flex-wrap items-center gap-4">
        <label className="text-sm font-medium">Desired clusters: {k}
          <input type="range" min="2" max="8" value={k} onChange={(e) => { setK(+e.target.value); setUsed(false); }} className="ml-3 align-middle accent-[#1f4a32]" /></label>
        <span className="text-sm text-ink/70">The dashed line shows the matching distance threshold.</span>
        <button className="btn-primary ml-auto" onClick={() => { setLabels(labels); setAlgo('Hierarchical (Ward)'); setUsed(true); }}>Use these clusters in Insights</button>
        {used && <span className="text-sm text-forest">Saved. Cluster Insights now uses this result.</span>}
      </div>
      <ChartCard title="Dendrogram" subtitle="Lower merges join similar farms. Tall branches join very different groups. Scroll sideways to see all branches."><Dendrogram nodes={nodes} labels={labels} threshold={threshold} /></ChartCard>
      <div className="grid lg:grid-cols-2 gap-6">
        <ChartCard title="Comparison with K-Means" subtitle={`Rows: hierarchical clusters. Columns: K-Means clusters, both with ${k} clusters. Counts are farms in both.`}>
          <div className="overflow-x-auto rounded-xl border border-sage-200"><table className="w-full text-sm"><thead><tr><th className="th">Hier. \ K-Means</th>{table.map((_, c) => <th key={c} className="th">Cluster {c + 1}</th>)}</tr></thead>
            <tbody>{table.map((row, h) => <tr key={h} className="border-t border-sage-100"><td className="td font-medium">Cluster {h + 1}</td>{row.map((v, c) => <td key={c} className="td" style={{ background: `rgba(47,107,71,${Math.min(0.6, v / 60)})` }}>{v}</td>)}</tr>)}</tbody></table></div>
          <p className="text-sm mt-3">Silhouette — hierarchical: <b>{fmt(silhouette(X, labels), 3)}</b> · K-Means: <b>{fmt(silhouette(X, km), 3)}</b>. Cluster numbers are matched by size only, so a strong match may appear off the diagonal.</p>
        </ChartCard>
        <ChartCard title="Cluster summary" subtitle={`Average features for the ${k} hierarchical clusters.`}><ClusterTable stats={stats} /></ChartCard>
      </div>
    </div>
  );
}
