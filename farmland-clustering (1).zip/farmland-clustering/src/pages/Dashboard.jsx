import { Link } from 'react-router-dom';
import { Rows3, Layers, Boxes, Cpu, ArrowRight } from 'lucide-react';
import StatCard from '../components/StatCard.jsx';
import { PageHead, Notice } from '../components/ChartCard.jsx';
import { useData } from '../context.jsx';
import { REFERENCE } from '../data/mockMetrics.js';

const FLOW = [
  ['Load data', '/dashboard/dataset', 'Use the synthetic sample or upload a CSV.'],
  ['Explore', '/dashboard/eda', 'Check distributions, outliers and correlations.'],
  ['Cluster', '/dashboard/kmeans', 'Pick K, inspect elbow and silhouette curves, run K-Means.'],
  ['Compare', '/dashboard/hierarchical', 'Cut the dendrogram and compare with K-Means.'],
  ['Interpret', '/dashboard/insights', 'Read what each cluster looks like.'],
];

export default function Dashboard() {
  const { records, source, clusterCount, algo, labels, resetSample } = useData();
  return (
    <div className="space-y-6">
      <PageHead title="Overview">Current dataset: {source.name}.</PageHead>
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard icon={Rows3} label="Farmland records" value={records.length} />
        <StatCard icon={Layers} label="Features" value={5} hint="Soil, irrigation, rainfall, yield, area" />
        <StatCard icon={Boxes} label="Clusters" value={clusterCount ?? 'Not run yet'} />
        <StatCard icon={Cpu} label="Selected algorithm" value={labels ? algo : 'None'} />
      </div>
      {source.uploaded && <Notice>You are viewing uploaded data. Run K-Means or hierarchical clustering to create cluster labels. <button className="underline" onClick={resetSample}>Switch back to the sample</button></Notice>}
      <section className="card p-5">
        <h2 className="text-xl font-semibold mb-4">Project workflow</h2>
        <ol className="grid md:grid-cols-5 gap-3">
          {FLOW.map(([t, to, d], i) => (
            <li key={t}><Link to={to} className="block h-full rounded-xl border border-sage-200 p-4 hover:bg-sage-50 transition-colors">
              <span className="text-sm text-forest font-medium flex items-center gap-1">{i + 1}. {t} <ArrowRight size={14} /></span><span className="text-sm text-ink/70">{d}</span></Link></li>))}
        </ol>
      </section>
      <section className="card p-5">
        <h2 className="text-xl font-semibold">Reference values from the course project</h2>
        <p className="text-sm text-ink/70 mt-1 max-w-3xl">These come from the original notebook and are shown for comparison only. This app computes its own numbers from the data loaded here, so they will differ for the synthetic sample.</p>
        <ul className="mt-3 text-sm grid sm:grid-cols-3 gap-2">
          <li className="rounded-xl bg-sage-50 p-3">Silhouette K=2: about {REFERENCE.silhouetteK2}</li>
          <li className="rounded-xl bg-sage-50 p-3">Silhouette K=3: about {REFERENCE.silhouetteK3}</li>
          <li className="rounded-xl bg-sage-50 p-3">Soil vs yield correlation: about {REFERENCE.soilYieldCorrelation}</li>
        </ul>
      </section>
    </div>
  );
}
