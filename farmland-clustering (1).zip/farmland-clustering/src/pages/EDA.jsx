import { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import ChartCard, { PageHead, Notice } from '../components/ChartCard.jsx';
import { useData } from '../context.jsx';
import { FEATURES } from '../data/mockFarmlandData.js';
import { col, describe, correlation, histogram, fmt } from '../utils/statistics.js';

const heat = (r) => { const t = Math.abs(r); const [R, G, B] = r >= 0 ? [31, 74, 50] : [181, 82, 59]; return `rgb(${Math.round(255 + (R - 255) * t)},${Math.round(255 + (G - 255) * t)},${Math.round(255 + (B - 255) * t)})`; };

function BoxPlot({ d, unit }) {
  const W = 640, pad = 30, span = d.max - d.min || 1; const x = (v) => pad + ((v - d.min) / span) * (W - 2 * pad);
  return (
    <svg viewBox={`0 0 ${W} 120`} className="w-full" role="img" aria-label="Box plot">
      <line x1={x(d.whiskerLo)} x2={x(d.whiskerHi)} y1="55" y2="55" stroke="#1f4a32" strokeWidth="2" />
      {[d.whiskerLo, d.whiskerHi].map((v) => <line key={v} x1={x(v)} x2={x(v)} y1="42" y2="68" stroke="#1f4a32" strokeWidth="2" />)}
      <rect x={x(d.q1)} y="35" width={Math.max(2, x(d.q3) - x(d.q1))} height="40" rx="6" fill="#cddac4" stroke="#1f4a32" strokeWidth="2" />
      <line x1={x(d.median)} x2={x(d.median)} y1="35" y2="75" stroke="#d9a441" strokeWidth="4" />
      {d.outliers.map((v, i) => <circle key={i} cx={x(v)} cy="55" r="4" fill="#b5523b"><title>{fmt(v, 2)} {unit}</title></circle>)}
      {[['min', d.min], ['Q1', d.q1], ['median', d.median], ['Q3', d.q3], ['max', d.max]].map(([l, v], i) => (
        <text key={l} x={x(v)} y={i % 2 ? 108 : 24} fontSize="11" textAnchor="middle" fill="#1b2a21">{l} {fmt(v, 1)}</text>))}
    </svg>
  );
}

export default function EDA() {
  const { records, source } = useData();
  const [bf, setBf] = useState('soil');
  const stats = useMemo(() => FEATURES.map((f) => ({ f, d: describe(col(records, f.key)), missing: records.filter((r) => r[f.key] == null || Number.isNaN(r[f.key])).length })), [records]);
  const corr = useMemo(() => FEATURES.map((a) => FEATURES.map((b) => correlation(col(records, a.key), col(records, b.key)))), [records]);
  const sel = stats.find((s) => s.f.key === bf);

  return (
    <div className="space-y-6">
      <PageHead title="Exploratory Data Analysis">Every statistic on this page is calculated from the loaded data ({source.name}). {!source.uploaded && 'The sample is synthetic, so patterns here are not findings about real farms.'}</PageHead>
      <ChartCard title="Feature distributions" subtitle="Number of records in each of 10 equal-width bins.">
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {FEATURES.map((f) => (
            <div key={f.key} className="rounded-xl border border-sage-100 p-3">
              <p className="text-sm font-medium mb-1">{f.label}{f.unit && ` (${f.unit})`}</p>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={histogram(col(records, f.key))} margin={{ left: -15, right: 5 }}>
                  <CartesianGrid vertical={false} stroke="#e3ebdd" /><XAxis dataKey="range" tick={false} label={{ value: f.label, position: 'insideBottom', fontSize: 11 }} height={28} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} /><Tooltip formatter={(v) => [v, 'Records']} labelFormatter={(l) => `${l} ${f.unit}`} />
                  <Bar dataKey="count" fill="#2f6b47" radius={[3, 3, 0, 0]} /></BarChart>
              </ResponsiveContainer>
            </div>))}
        </div>
      </ChartCard>

      <ChartCard title="Box plot" subtitle="Feature ranges differ a lot, so inspect one feature at a time. Red dots are possible outliers (beyond 1.5 × IQR).">
        <div className="flex flex-wrap gap-2 mb-3">{FEATURES.map((f) => (
          <button key={f.key} onClick={() => setBf(f.key)} className={`btn !py-1.5 ${bf === f.key ? 'bg-forest text-white' : 'bg-sage-100 text-forest hover:bg-sage-200'}`}>{f.label}</button>))}</div>
        <BoxPlot d={sel.d} unit={sel.f.unit} />
      </ChartCard>

      <ChartCard title="Correlation heatmap" subtitle="Pearson correlation between every pair of features.">
        <div className="overflow-x-auto"><div className="grid gap-1 min-w-[520px]" style={{ gridTemplateColumns: 'minmax(90px,1fr) repeat(5, minmax(70px,1fr))' }}>
          <div />{FEATURES.map((f) => <div key={f.key} className="text-xs font-medium text-center">{f.short}</div>)}
          {FEATURES.map((a, i) => [<div key={a.key} className="text-xs font-medium self-center">{a.short}</div>,
            ...FEATURES.map((b, j) => <div key={b.key} title={`${a.label} vs ${b.label}`} className="rounded-lg py-3 text-center text-sm font-medium" style={{ background: heat(corr[i][j]), color: Math.abs(corr[i][j]) > 0.55 ? '#fff' : '#1b2a21' }}>{corr[i][j].toFixed(2)}</div>)])}
        </div></div>
        <p className="text-sm text-ink/70 mt-3 max-w-3xl">Green cells are positive: both features tend to rise together. Rust cells are negative: one rises as the other falls. Values near 0 (pale cells) show a weak linear relationship. Correlation does not show cause.</p>
      </ChartCard>

      <ChartCard title="EDA summary" subtitle="Descriptive statistics, ranges, missing values and possible outliers.">
        <div className="overflow-x-auto rounded-xl border border-sage-200"><table className="w-full text-sm">
          <thead><tr>{['Feature', 'Missing', 'Mean', 'Std dev', 'Min', 'Q1', 'Median', 'Q3', 'Max', 'Outliers'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
          <tbody>{stats.map(({ f, d, missing }) => <tr key={f.key} className="border-t border-sage-100"><td className="td font-medium">{f.label}</td><td className="td">{missing}</td>
            {[d.mean, d.std, d.min, d.q1, d.median, d.q3, d.max].map((v, i) => <td key={i} className="td">{fmt(v, 2)}</td>)}<td className="td">{d.outliers.length}</td></tr>)}</tbody></table></div>
        <div className="mt-3 space-y-1 text-sm">{stats.filter((s) => s.d.outliers.length).map(({ f, d }) => <p key={f.key}><b>{f.label}:</b> {d.outliers.map((v) => fmt(v, 2)).join(', ')}</p>)}
          {!stats.some((s) => s.d.outliers.length) && <Notice tone="ok">No possible outliers were found by the 1.5 × IQR rule.</Notice>}</div>
        {source.skipped > 0 && <p className="text-sm text-ink/70 mt-2">{source.skipped} uploaded rows with blank values were skipped, so the loaded data has no missing values.</p>}
      </ChartCard>
    </div>
  );
}
