import { Link } from 'react-router-dom';
import { BarChart3, Network, GitBranch, Lightbulb, Upload, Search, ScatterChart, Map } from 'lucide-react';
import Navbar from '../components/Navbar.jsx';

const FEATURE_CARDS = [
  { icon: BarChart3, title: 'Exploratory analysis', text: 'Distributions, spread, outliers and correlations for five farm measurements.' },
  { icon: Network, title: 'K-Means', text: 'Group farms around centroids and compare K using the elbow and silhouette charts.' },
  { icon: GitBranch, title: 'Hierarchical clustering', text: 'Read a dendrogram to see which farms merge first, then cut it into zones.' },
  { icon: Lightbulb, title: 'Cluster insights', text: 'Plain-language descriptions of each zone, written from its actual averages.' },
];
const STEPS = [
  { icon: Upload, title: 'Upload farmland data', text: 'Bring a CSV with the five required columns, or start with the sample.' },
  { icon: Search, title: 'Explore the dataset', text: 'Search, sort and chart the records before clustering.' },
  { icon: ScatterChart, title: 'Analyze and visualize clusters', text: 'Run K-Means or Ward hierarchical clustering and compare them.' },
  { icon: Map, title: 'Interpret farmland zones', text: 'Read what makes each zone different and decide what to do with it.' },
];
const ZONE = ['#1f6b45', '#d9a441', '#6a5acd'];

function Field() {
  return (
    <svg viewBox="0 0 420 340" className="w-full rounded-3xl" role="img" aria-label="Illustration of farm fields in three zones">
      <rect width="420" height="340" fill="#e3ebdd" />
      <circle cx="330" cy="62" r="30" fill="#d9a441" />
      <path d="M0 150 Q110 100 220 140 T420 120 V340 H0Z" fill="#cddac4" />
      {[0, 1, 2].map((z) => Array.from({ length: 4 }, (_, i) => (
        <path key={`${z}${i}`} d={`M${-10} ${170 + z * 52 + i * 11} Q 150 ${130 + z * 52 + i * 11 - z * 6} 430 ${178 + z * 52 + i * 11 + z * 8}`}
          stroke={ZONE[z]} strokeWidth="7" strokeLinecap="round" fill="none" opacity={0.85} />)))}
    </svg>
  );
}

export default function Home() {
  return (
    <div>
      <Navbar />
      <header className="max-w-6xl mx-auto px-5 py-10 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl sm:text-5xl font-bold leading-tight">Group farmland into zones that share the same conditions</h1>
          <p className="mt-5 text-lg text-ink/75 max-w-prose">Farmland Zone Clustering applies K-Means and hierarchical clustering to soil, irrigation, rainfall, yield and land area, then helps you read what each zone means.</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link to="/dashboard" className="btn-primary !px-6 !py-3">Explore Dashboard</Link>
            <Link to="/dashboard/kmeans" className="btn-ghost !px-6 !py-3">Try K-Means</Link>
          </div>
        </div>
        <Field />
      </header>
      <section className="max-w-6xl mx-auto px-5 py-10">
        <h2 className="text-2xl font-bold">What is farmland clustering?</h2>
        <p className="mt-3 max-w-3xl text-ink/75">Clustering is unsupervised: no farm is labelled in advance. The algorithm looks for farms with similar measurements and puts them in the same group. Those groups can then guide irrigation planning, crop choice or further study.</p>
        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {FEATURE_CARDS.map(({ icon: Icon, title, text }) => (
            <div key={title} className="card p-5 transition-shadow hover:shadow-md"><Icon className="text-forest" /><h3 className="mt-3 font-semibold text-lg">{title}</h3><p className="mt-1 text-sm text-ink/70">{text}</p></div>))}
        </div>
      </section>
      <section className="bg-forest-dark text-sage-100 mt-10">
        <div className="max-w-6xl mx-auto px-5 py-14">
          <h2 className="text-2xl font-bold !text-white">How it works</h2>
          <ol className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {STEPS.map(({ icon: Icon, title, text }, i) => (
              <li key={title}><div className="flex items-center gap-3"><span className="h-9 w-9 rounded-full bg-wheat text-forest-dark grid place-items-center font-bold">{i + 1}</span><Icon size={20} /></div>
                <h3 className="mt-3 font-semibold !text-white">{title}</h3><p className="mt-1 text-sm text-sage-200">{text}</p></li>))}
          </ol>
          <p className="mt-10 text-sm text-sage-300 max-w-3xl">The included sample is 120 synthetic records created in code. It is not real survey data.</p>
        </div>
      </section>
    </div>
  );
}
