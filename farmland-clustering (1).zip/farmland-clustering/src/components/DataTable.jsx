import { useMemo, useState } from 'react';
import { ArrowUp, ArrowDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { FEATURES } from '../data/mockFarmlandData.js';
import { CLUSTER_COLORS } from '../data/mockMetrics.js';
import { fmt } from '../utils/statistics.js';

export default function DataTable({ columns, rows, pageSize = 10, empty = 'No records match.' }) {
  const [sort, setSort] = useState({ key: null, dir: 1 });
  const [page, setPage] = useState(0);
  const sorted = useMemo(() => {
    if (!sort.key) return rows;
    return [...rows].sort((a, b) => (a[sort.key] > b[sort.key] ? 1 : a[sort.key] < b[sort.key] ? -1 : 0) * sort.dir);
  }, [rows, sort]);
  const pages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const cur = Math.min(page, pages - 1);
  const view = sorted.slice(cur * pageSize, cur * pageSize + pageSize);
  const toggle = (key) => { setSort((s) => ({ key, dir: s.key === key ? -s.dir : 1 })); setPage(0); };

  return (
    <div>
      <div className="overflow-x-auto rounded-xl border border-sage-200">
        <table className="w-full text-sm">
          <thead><tr>{columns.map((c) => (
            <th key={c.key} className="th"><button className="inline-flex items-center gap-1" onClick={() => toggle(c.key)}>
              {c.label}{sort.key === c.key && (sort.dir === 1 ? <ArrowUp size={14} /> : <ArrowDown size={14} />)}</button></th>))}</tr></thead>
          <tbody>
            {view.map((r, i) => <tr key={r.id ?? i} className="border-t border-sage-100 hover:bg-sage-50">{columns.map((c) => <td key={c.key} className="td">{c.render ? c.render(r) : r[c.key]}</td>)}</tr>)}
            {!view.length && <tr><td className="td text-ink/60 py-8 text-center" colSpan={columns.length}>{empty}</td></tr>}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between mt-3 text-sm">
        <span className="text-ink/70">{sorted.length ? `${cur * pageSize + 1}–${Math.min(sorted.length, (cur + 1) * pageSize)} of ${sorted.length}` : '0 records'}</span>
        <div className="flex items-center gap-2">
          <button className="btn-ghost !px-2" disabled={cur === 0} onClick={() => setPage(cur - 1)} aria-label="Previous page"><ChevronLeft size={16} /></button>
          <span>Page {cur + 1} of {pages}</span>
          <button className="btn-ghost !px-2" disabled={cur >= pages - 1} onClick={() => setPage(cur + 1)} aria-label="Next page"><ChevronRight size={16} /></button>
        </div>
      </div>
    </div>
  );
}

export const ClusterDot = ({ c }) => <span className="inline-flex items-center gap-2"><i className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: CLUSTER_COLORS[c] }} />Cluster {c + 1}</span>;

// Shared cluster summary table (count + feature means).
export function ClusterTable({ stats }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-sage-200">
      <table className="w-full text-sm">
        <thead><tr><th className="th">Cluster</th><th className="th">Records</th>{FEATURES.map((f) => <th key={f.key} className="th">Avg {f.short}{f.unit && ` (${f.unit})`}</th>)}</tr></thead>
        <tbody>{stats.clusters.map((c) => (
          <tr key={c.id} className="border-t border-sage-100"><td className="td"><ClusterDot c={c.id} /></td><td className="td">{c.count}</td>
            {FEATURES.map((f) => <td key={f.key} className="td">{fmt(c.means[f.key], f.key === 'yield' ? 2 : 1)}</td>)}</tr>))}</tbody>
      </table>
    </div>
  );
}
