import { Link } from 'react-router-dom';
import { Sprout } from 'lucide-react';
export default function Navbar() {
  return (
    <nav className="flex items-center justify-between max-w-6xl mx-auto px-5 py-5">
      <Link to="/" className="flex items-center gap-2 font-serif text-xl font-bold text-forest-dark"><Sprout className="text-forest" /> Farmland Zones</Link>
      <Link to="/dashboard" className="btn-primary">Open dashboard</Link>
    </nav>
  );
}
