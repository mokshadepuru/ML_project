import { useState } from 'react';
import { NavLink, Outlet, Link } from 'react-router-dom';
import { LayoutDashboard, Table2, BarChart3, Network, GitBranch, Lightbulb, Menu, X, Sprout } from 'lucide-react';

const ITEMS = [
  { to: '/dashboard', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/dashboard/dataset', label: 'Dataset Explorer', icon: Table2 },
  { to: '/dashboard/eda', label: 'Exploratory Data Analysis', icon: BarChart3 },
  { to: '/dashboard/kmeans', label: 'K-Means Clustering', icon: Network },
  { to: '/dashboard/hierarchical', label: 'Hierarchical Clustering', icon: GitBranch },
  { to: '/dashboard/insights', label: 'Cluster Insights', icon: Lightbulb },
];

export function DashboardShell() {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen lg:flex">
      <header className="lg:hidden flex items-center justify-between bg-forest-dark text-white px-4 py-3">
        <span className="font-serif text-lg">Farmland Zones</span>
        <button aria-label="Open menu" onClick={() => setOpen(true)}><Menu /></button>
      </header>
      {open && <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setOpen(false)} />}
      <aside className={`fixed lg:sticky top-0 z-40 h-screen w-72 shrink-0 bg-forest-dark text-sage-100 p-5 flex flex-col transition-transform ${open ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
        <div className="flex items-center justify-between mb-8">
          <Link to="/" className="flex items-center gap-2 font-serif text-xl text-white"><Sprout className="text-wheat" /> Farmland Zones</Link>
          <button className="lg:hidden" aria-label="Close menu" onClick={() => setOpen(false)}><X /></button>
        </div>
        <nav className="space-y-1">
          {ITEMS.map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)}
              className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${isActive ? 'bg-forest-light text-white' : 'hover:bg-forest'}`}>
              <Icon size={18} /> {label}
            </NavLink>
          ))}
        </nav>
        <p className="mt-auto text-xs text-sage-300">K-Means and Ward clustering run in your browser. Sample data is synthetic.</p>
      </aside>
      <main className="flex-1 min-w-0 p-4 sm:p-8 max-w-7xl"><Outlet /></main>
    </div>
  );
}
