export default function StatCard({ icon: Icon, label, value, hint }) {
  return (
    <div className="card p-5 flex items-start gap-4 transition-shadow hover:shadow-md">
      <div className="rounded-xl bg-sage-100 p-3 text-forest"><Icon size={22} /></div>
      <div className="min-w-0">
        <p className="text-sm text-ink/70">{label}</p>
        <p className="font-serif text-2xl font-bold text-forest-dark truncate">{value}</p>
        {hint && <p className="text-xs text-ink/60 mt-0.5">{hint}</p>}
      </div>
    </div>
  );
}
