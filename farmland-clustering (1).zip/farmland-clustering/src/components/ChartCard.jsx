// kind: 'computed' = calculated from the loaded data; 'demo' = illustrative / simulated.
export function Badge({ kind = 'computed' }) {
  return kind === 'demo'
    ? <span className="rounded-full bg-wheat/25 text-[#7a5a14] text-xs px-2.5 py-0.5">Illustrative</span>
    : <span className="rounded-full bg-sage-100 text-forest text-xs px-2.5 py-0.5">Calculated from loaded data</span>;
}
export default function ChartCard({ title, subtitle, kind = 'computed', actions, children, className = '' }) {
  return (
    <section className={`card p-5 ${className}`}>
      <div className="flex flex-wrap items-start justify-between gap-2 mb-3">
        <div><h3 className="text-lg font-semibold">{title}</h3>{subtitle && <p className="text-sm text-ink/70 max-w-prose">{subtitle}</p>}</div>
        <div className="flex items-center gap-2">{actions}<Badge kind={kind} /></div>
      </div>
      {children}
    </section>
  );
}
export const Notice = ({ tone = 'info', children }) => (
  <div className={`rounded-xl px-4 py-3 text-sm ${tone === 'error' ? 'bg-rust/10 text-rust border border-rust/30' : tone === 'ok' ? 'bg-sage-100 text-forest border border-sage-300' : 'bg-wheat/20 text-[#6b4d10] border border-wheat/50'}`}>{children}</div>
);
export const PageHead = ({ title, children }) => (
  <div className="mb-6"><h1 className="text-3xl font-bold">{title}</h1><p className="text-ink/70 mt-1 max-w-3xl">{children}</p></div>
);
