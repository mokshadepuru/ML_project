export const CLUSTER_COLORS = ['#1f6b45', '#d9a441', '#6a5acd', '#c0563b', '#2a8fa8', '#8a8a3a', '#a04f8f', '#555f66'];

// Reference values quoted from the original course project notebook.
// They are NOT computed here and are shown only for comparison.
export const REFERENCE = { kMeansK: 3, silhouetteK2: 0.337, silhouetteK3: 0.301, soilYieldCorrelation: 0.74 };
