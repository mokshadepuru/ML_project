// SYNTHETIC sample data: 120 farmland records from a seeded random generator.
// Replace with real data (CSV upload, or an API call to your Python backend).
import { rng } from '../utils/rng.js';

export const FEATURES = [
  { key: 'soil', label: 'Soil Quality Score', short: 'Soil', unit: '' },
  { key: 'irrigation', label: 'Irrigation Availability', short: 'Irrigation', unit: '%' },
  { key: 'rainfall', label: 'Annual Rainfall', short: 'Rainfall', unit: 'mm' },
  { key: 'yield', label: 'Crop Yield', short: 'Yield', unit: 't' },
  { key: 'area', label: 'Land Area', short: 'Area', unit: 'ac' },
];
export const KEYS = FEATURES.map((f) => f.key);

// Three hidden groups with deliberately mixed profiles (not simply low / medium / high).
const GROUPS = [
  { n: 45, soil: 78, irrigation: 72, rainfall: 1000, area: 40 },
  { n: 40, soil: 55, irrigation: 28, rainfall: 1350, area: 85 },
  { n: 35, soil: 38, irrigation: 50, rainfall: 600, area: 22 },
];

function build() {
  const r = rng(2024);
  const gauss = () => Math.sqrt(-2 * Math.log(r() || 1e-9)) * Math.cos(2 * Math.PI * r());
  const rows = [];
  GROUPS.forEach((g) => {
    for (let i = 0; i < g.n; i++) {
      const soil = Math.min(100, Math.max(5, g.soil + gauss() * 7));
      rows.push({
        soil: +soil.toFixed(1),
        irrigation: +Math.min(100, Math.max(5, g.irrigation + gauss() * 8)).toFixed(1),
        rainfall: Math.round(g.rainfall + gauss() * 120),
        yield: +Math.max(0.5, 0.075 * soil - 0.3 + gauss() * 0.6).toFixed(2),
        area: +Math.max(2, g.area + gauss() * 10).toFixed(1),
      });
    }
  });
  for (let i = rows.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [rows[i], rows[j]] = [rows[j], rows[i]]; }
  return rows.map((row, i) => ({ id: `F-${String(i + 1).padStart(3, '0')}`, ...row }));
}
export const MOCK_RECORDS = build();
