import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Dashboard from './pages/Dashboard.jsx';
import DatasetExplorer from './pages/DatasetExplorer.jsx';
import EDA from './pages/EDA.jsx';
import KMeans from './pages/KMeans.jsx';
import HierarchicalClustering from './pages/HierarchicalClustering.jsx';
import ClusterInsights from './pages/ClusterInsights.jsx';
import { DashboardShell } from './components/Sidebar.jsx';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/dashboard" element={<DashboardShell />}>
        <Route index element={<Dashboard />} />
        <Route path="dataset" element={<DatasetExplorer />} />
        <Route path="eda" element={<EDA />} />
        <Route path="kmeans" element={<KMeans />} />
        <Route path="hierarchical" element={<HierarchicalClustering />} />
        <Route path="insights" element={<ClusterInsights />} />
      </Route>
      <Route path="*" element={<Home />} />
    </Routes>
  );
}
