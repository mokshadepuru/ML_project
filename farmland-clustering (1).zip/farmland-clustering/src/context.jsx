import { createContext, useContext, useState } from 'react';
import { MOCK_RECORDS } from './data/mockFarmlandData.js';
import { runKMeans } from './utils/statistics.js';

const Ctx = createContext(null);
export const useData = () => useContext(Ctx);

export function DataProvider({ children }) {
  const [records, setRecords] = useState(MOCK_RECORDS);
  const [source, setSource] = useState({ name: 'Synthetic sample (generated in code)', uploaded: false, skipped: 0 });
  const [labels, setLabels] = useState(() => runKMeans(MOCK_RECORDS, 3)); // real K-Means, K = 3, on synthetic data
  const [algo, setAlgo] = useState('K-Means');

  // Uploaded data is NOT clustered automatically; run an algorithm to get labels.
  const loadRecords = (rows, src) => { setRecords(rows); setSource(src); setLabels(null); };
  const resetSample = () => { setRecords(MOCK_RECORDS); setSource({ name: 'Synthetic sample (generated in code)', uploaded: false, skipped: 0 }); setLabels(runKMeans(MOCK_RECORDS, 3)); setAlgo('K-Means'); };
  const clusterCount = labels ? Math.max(...labels) + 1 : null;

  return <Ctx.Provider value={{ records, source, labels, setLabels, algo, setAlgo, loadRecords, resetSample, clusterCount }}>{children}</Ctx.Provider>;
}
