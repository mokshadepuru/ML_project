export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: {
    colors: {
      forest: { DEFAULT: '#1f4a32', dark: '#143323', light: '#2f6b47' },
      sage: { 50: '#f1f5ee', 100: '#e3ebdd', 200: '#cddac4', 300: '#b0c4a4', 500: '#7f9b70' },
      cream: '#f6f1e1', ink: '#1b2a21', wheat: '#d9a441', rust: '#b5523b',
    },
    fontFamily: { sans: ['"Public Sans"', 'system-ui', 'sans-serif'], serif: ['Fraunces', 'Georgia', 'serif'] },
  } },
  plugins: [],
};
